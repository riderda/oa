#include "seqstack.h"
// #include <stdlib.h>
void InitStack(SeqStack * stack){
    stack->top = -1;
}


int IsEmpty(SeqStack * stack){
    if(stack->top == -1){
        return 1;
    }else{
        return 0;
    }
}

int SeqStack_Top(SeqStack * stack){
    if(!IsEmpty(stack)){
        return stack->top;
    }
    return INFINITY;
}

int SeqStack_Pop(SeqStack * stack){
    if (!IsEmpty(stack)){
        return stack->data[stack->top--];//弹出元素后top减一
    }
    return INFINITY;
}

void SeqStack_Push(SeqStack * stack, int val){
    if(stack->top >= MAXSIZE - 1){
        return;
    }
    stack->top++;
    stack->data[stack->top]=val;
}
void SeqStack_Destory(SeqStack * stack){
    if(!IsEmpty(stack)){
        free(stack);
    }
}