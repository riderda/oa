#include<stdio.h>
#include<stdlib.h>
struct Header{
    int length;
    struct Node * next;
};
struct Node{
    int data;
    struct Node * next;
};

typedef struct Header pHead;
typedef struct Node List;

pHead * createList(){
    pHead * ph = (pHead *)malloc(sizeof(pHead));
    ph->length = 0;
    ph->next = NULL;
    return ph;
}

int Size(pHead * ph){
    if(ph == NULL){
        return 0;
    }
    return ph->length;
}

int Insert(pHead * ph, int pos, int val){
    if (ph == NULL || pos < 0 || pos > ph->length){
        return 0;
    }
    List * pval = (List *)malloc(sizeof(List));
    pval->data = val;
    List * pCur = ph->next; //这个点是头节点的尾部，也就是要插入的节点，如果是第一次插入，则是替换该节点。否则插在该节点后
    if(pos == 0){
        ph->next = pval;
        pval->next = pCur;//不可以直接写NULL，这个节点作为复制节点还是有意义的
    }else{
        for(int i=1; i<pos; i++){
            pCur = pCur->next; //遍历切换
        }
        pval->next = pCur->next;
        pCur->next = pval;
    }
    ph->length++;
    return 1;
}

List * Find(pHead * ph, int val){
    if(ph == NULL){
        return NULL;
    }
    List * temp = ph->next;
    while(temp->next != NULL){
        if(temp->data == val){
            return temp;
        }
    }
    return NULL;
}

List * Delete(pHead * ph, int val){
    if(ph->next == NULL){
        return NULL;
    }
    List * pval = Find(ph,val);
    if(pval == NULL){
        return NULL;
    }

    List * pRe = ph->next;
    //原来的办法通用性写的感觉不是很好
    //原因应该是头节点和链节点不一样的原因，无法复用头节点
    if(pRe->data == val){
        ph->next = pRe->next;
        ph->length--;
        return pRe;
    }else{
        for(int i=0; i<ph->length; i++){
            //这里的i只是用于循环次数，遍历链表
            if(pRe->next->data == pval->data){
                pRe->next = pval->next;
                ph->length--;
                return pval;
            }
            pRe = pRe->next;
        }
    }
}