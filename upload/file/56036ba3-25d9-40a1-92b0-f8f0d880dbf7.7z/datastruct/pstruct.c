#include<stdio.h>

struct sui{
    char c;
    char b[2];
    int a;
   
};

int main(){
    struct sui a;
    struct sui * b = &a;
    b->a = 10;
    b->b[0] = 'a';
    b->b[1] = 'b';
    b->c = 'c';
    printf("%c",*((int *)b));
    // printf("\n%d",sizeof(void *));
    return 0;
}