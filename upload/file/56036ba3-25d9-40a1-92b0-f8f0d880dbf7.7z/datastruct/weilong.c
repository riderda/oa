#include<stdio.h>

int main(){
    int a = 1;
    printf("hello world\n");
    int b = 0;
    for(int c=0;c<22;c++){
        printf("c");
        int d=0;
    }
    
    return 0;    
}