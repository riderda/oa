#include<stdio.h>
#include<stdlib.h>
#include<memory.h>
typedef struct _tag_SqeList
{
    /* data */
    int capacity;
    int length;
    int * node;  
}SeqList;

SeqList * SeqList_Create(int capacity){
    int errCode;
    SeqList * temp = NULL;
    temp = (SeqList *)malloc(sizeof(SeqList));
    if (temp == NULL){
        errCode = 1;
        printf("errCode : %d",errCode);
        return NULL;
    }
    memset(temp,0,sizeof(SeqList));
    temp->capacity = capacity;
    temp->length = 0;
    temp->node = (int *)malloc(sizeof(int)*capacity);
    if (temp->node == NULL){
        errCode = 2;
        printf("errCode : %d",errCode);
        return NULL;
    }
    return temp;
}

int SeqList_Capacity(SeqList * list){
    SeqList * temp = NULL;
    if (list == NULL){
        return 0;
    }
    temp = list;
    return temp->capacity;
}

int SeqList_Length(SeqList * list){
    SeqList * temp = NULL;
    if(list == NULL){
        return 0;
    }
    temp = list;
    return temp->length;
}

int SeqList_Insert(SeqList * list, int * node, int pos){
    SeqList * temp = NULL;
    if (list == NULL || node == NULL){
        return -1;
    }
    temp = list;
    if (temp->length >= temp->capacity){
        return -2;
    }

    if (pos > temp->length){
        pos = temp->length;
    }
    for (int i=temp->length; i > pos; i--){
        temp->node[i] = temp->node[i-1];
    }
    temp->node[pos] = *node;
    temp->length++;
    return 0;

}
int * SeqList_Delete(SeqList * list, int pos){
    SeqList * temp = list;
    int * node = NULL;
    if (list == NULL || pos < 0 || pos > temp->capacity){
        return NULL;
    }
    node = &temp->node[pos];
    for(; pos < temp->length-1; pos++){
        temp->node[pos] = temp->node[pos+1];
    }
    temp->length--;
    return node;
}
int * SeqList_Get(SeqList * list, int pos){
    SeqList * tlist = NULL;
    int * node = NULL;
    tlist = list;
    if (tlist == NULL || pos <0 || pos > tlist->capacity){
        return NULL;
    }
    node = tlist->node[pos];
    return node;
}

void SeqList_Clear(SeqList * list){
    SeqList * temp = NULL;
    if(list == NULL){
        return ;
    }
    temp = list;
    temp->length = 0; 
    memset(temp->node,0,sizeof(int)*temp->capacity);
    return ;
}

void SeqList_Destory(SeqList * list){
    SeqList * temp = NULL;
    if(list == NULL){
        return ;
    }
    temp = list;
    if (temp->node != NULL){
         free(temp->node);
    }
    free(temp);
    return;
}
int main(){
    SeqList * list = NULL;
    list = SeqList_Create(10);
    printf("%d\n",SeqList_Length(list));
    int i = 3;
    SeqList_Insert(list,&i,1);
    printf("%d\n",SeqList_Length(list));
    printf("%d\n",*SeqList_Delete(list,1));
    printf("%d\n",SeqList_Length(list));

}